/* Automatically generated from config.h: public/compiler config. */

#define PQXX_HAVE_GCC_PURE 1
#define PQXX_HAVE_GCC_VISIBILITY 1
#define PQXX_HAVE_PATH 1
#define PQXX_HAVE_STRERROR_R 1
