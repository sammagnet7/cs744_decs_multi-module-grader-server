
# Systems_IITB
Git repo link:  https://github.com/sammagnet7/Systems_IITB.git



_______________________________________________________VERSION1___________________________________________________________


#Zip the server side code and send it to the server

Step 1 - set the "client_machine_path" in "/server_side/server_snapshot.sh" (ex- hostname@IP:~/Documents) so that server 
         can send the log files to client

Step 2 - zip -r server_side.zip server_side			(Client Side)
Step 3 - ssh labuser@10.130.154.66					(Client Side)
Step 4 - cd ~/cs744/Autograder_server_V1			(after creating the appropriate directory on server side)
Step 5 - scp labuser@10.130.154.66:~/cs744/Autograder_server_V1		(Client Side)
Step 6 - unzip server_side.unzip					(Server side)
Step 7 - cd server_side/
Step 8 - Open another tab, again do ssh as mentioned above and move to /server_side
Step 9 - Checkout to Autograder_branch_version to be tested			(Client Side)
		 git branch -a 				(check current branch)
		 git checkout Autograder_V1 (use this command to checkout to the desired branch)

Step 10 - cd client_side 			(client side)
Step 11 - make						(client side)
Step 12 - make						(server side)
Step 13 - cd ../perf_test/			(client side)
Step 14 - make						(client side)
Step 15 - change serverip_port in loadtest.sh	(if required)
	      change server_ip in plot_client_stats	(if required)
Step 16 - python3 plot_client_stats.py

########## GIVE BELOW MENTIONED VALUES(for ex), DON'T HIT ENTER AFTER GIVING THOSE VALUES################
Enter minimum clients:  1
Enter maximum clients:  50
Enter steps	     :  5

Step 17 - ./server <port_no>	(start the server)
Step 18 - ./server_snapshot.sh  (Run this command in the other tab on server)
Step 19 - After step 17 and 18 in sequence, hit enter on the client side
Step 20 - After the graph is generated on client side stop the server and enter client machine password in the second 
          tab where "server_snapshot.sh" is running 
Step 21 - python3 plot_server_stats.py       (Run this step to generate plot on client_side)

# line

______________________________________________________VERSION2_________________________________________________________

Same as version 1, just make changes in name of version (for ex - Autograder_server_V2)

# line

______________________________________________________VERSION3_________________________________________________________

Steps - same as version 1,make changes in name of version (for ex - Autograder_server_V3) and one below mentioned change
Step 17 - ./server <port_no> <thread_pool_size>		(give thread_pool_size as an extra argument)

# line
______________________________________________________VERSION4_________________________________________________________

## client_side
cd Systems_IITB 

Step 1 - set the "client_machine_path" in "/server_side/server_snapshot.sh" (ex- hostname@IP:~/Documents) so that server 
         can send the log files to client

Step 2 - zip -r server_side.zip server_side			(Client Side)
Step 3 - ssh labuser@10.130.154.66					(Client Side)
Step 4 - cd ~/cs744/Autograder_server_V4			(after creating the appropriate directory on server side)
Step 5 - scp labuser@10.130.154.66:~/cs744/Autograder_server_V4		(Client Side)
Step 6 - unzip server_side.unzip					(Server side)
Step 7 - cd server_side/
Step 8 - Open 4 tabs, do ssh as mentioned above and move to /server_side
Step 9 - Checkout to Autograder_branch_version to be tested			(Client Side)
		 git branch -a 				(check current branch)
		 git checkout Autograder_V4 (use this command to checkout to the desired branch)

Step 10 - cd client_side 			(client side)
Step 11 - make						(client side)
Step 12 - make						(server side)
Step 13 - cd ../perf_test/			(client side)
Step 14 - make						(client side)
Step 15 - change serverip_port in loadtest.sh	(if required)
	      change server_ip in plot_client_stats	(if required)
Step 16 - python3 plot_client_stats.py

########## GIVE BELOW MENTIONED VALUES(for ex), DON'T HIT ENTER AFTER GIVING THOSE VALUES################
Enter minimum clients:  1
Enter maximum clients:  50
Enter steps	     :  5

Step 17 - ./submission_server 8080 <no_of_threads>			(Tab1 - server side)
		  ./query_server 9090 <no_of_threads>				(Tab2 - server side)
		  ./grader_server <no_of_threads>					(Tab3 - server side)
		  ./server_snapshot.sh 								(Tab4 - server side)
Step 18 - After step 17 in sequence, hit enter on the client side
Step 19 - After the graph is generated on client side stop the server and enter client machine password in the second 
          tab where "server_snapshot.sh" is running 
Step 20 - python3 plot_server_stats.py       (Run this step to generate plot on client_side)


# line
