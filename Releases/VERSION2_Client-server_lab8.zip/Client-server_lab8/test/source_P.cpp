#include <iostream>

using namespace std;

int main()
{
    for(int i=1;i<=10;i++)  //for loop used to increament each time loop runs.
    {
        cout<<i<<" ";
    }

    return 0;
}